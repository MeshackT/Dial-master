# dial
Application meant for sharing contacts, Easey access to emergency contacts, 
Calling your friends and whatsapp directory

## Getting Started

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

My address
Barry Marais Rd & Morena str, Witpoortjie 117-ir, Brakpan South Africa


https://maps.googleapis.com/maps/api/staticmap?center:$lat,$lng&xoom=14&size=600x400&markers=anchor:32,10%7Cicon:https://goo.gl/5y3S82%7CCanberra+ACT&key=YOUR_API_KEY


flutter pub global run rename --appname "Dial FSH"

flutter pub global run rename --bundleId com.meshacknkosi.dial


keytool -genkey -v -keystore C:\Users\mesha\Desktop/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload


https://github.com/MeshackT/Policies/blob/main/Privacy-Dial.md


try this one
contacts_service: ^0.6.3