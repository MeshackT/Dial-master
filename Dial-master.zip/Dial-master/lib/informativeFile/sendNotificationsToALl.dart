import 'package:flutter/cupertino.dart';

class SendNotificationsToAll extends StatefulWidget {
  const SendNotificationsToAll({Key? key}) : super(key: key);

  @override
  State<SendNotificationsToAll> createState() => _SendNotificationsToAllState();
}

class _SendNotificationsToAllState extends State<SendNotificationsToAll> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
